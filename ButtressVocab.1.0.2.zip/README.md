# ButtressVocab
Browser addon to strengthen vocabulary while reading things on the internet.
