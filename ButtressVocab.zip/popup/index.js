today = new Date();
today_str = today.getFullYear().toString() + ( today.getMonth() + 1  ).toString() + today.getDate().toString();
words = JSON.parse(localStorage.getItem(today_str));
word_container = document.getElementById("words-table");
for(i in words){
    elem = document.createElement("p");
    word_container.appendChild(elem);
    elem.innerHTML = words[i]
}
