browser.runtime.onMessage.addListener(get_data_from_dictionary);

function send_data(result){
    browser.tabs.query({
        currentWindow: true,
        active: true
    }).then(function(tabs){
        browser.tabs.sendMessage(
            tabs[0].id,
            {response: result});
    })
}

today = new Date()
today_str = today.getFullYear().toString() + ( today.getMonth() + 1 ).toString() + today.getDate().toString()
words_list = new Set(localStorage.getItem(today_str));

function save_data(word, result){
    today = new Date()
    today_str = today.getFullYear().toString() + ( today.getMonth() + 1 ).toString() + today.getDate().toString()
    words_list.add(word)
    // Store words looked up today.
    localStorage.setItem(today_str, JSON.stringify(Array.from(words_list)))
    // // Store day on which word was looked up.
    // localStorage.setItem(word, today_str)
}

function get_data_from_dictionary(word){
    word = word.term
    url_offset = "/entries/en/"
    var api_url = "http://api.wordnik.com:80/v4/word.json/"+word+"/definitions?limit=5&includeRelated=true&useCanonical=true&includeTags=false&api_key=409b7cc48186d3a77732a03dc040dd8e977137f44a87a0b8f";
    console.debug("Searching the word " + word + " at " + api_url)
    $.ajax({
        dataType: "json",
        url: api_url,
        success: function(result, status){
            send_data(result)
            save_data(word, result)
        },
        error: function(result, status, error_thrown){
            if(result.status == 404)
                console.debug("Definition not found!")
            else
                console.debug("Unknown error, Code: " + result.status + ". Msg: " + error_thrown + status)
            send_data("")
        }
    })
}


