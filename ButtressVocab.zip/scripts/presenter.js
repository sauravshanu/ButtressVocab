$(document).dblclick(function(){
    dblclickSlection();
});

var selectedText;
function dblclickSlection(){
    flag = 0;
    if (window.getSelection) {
        selectedText = window.getSelection();
    } else if (document.getSelection) {
        selectedText = document.getSelection();
    } else if (document.selection) {
        selectedText = document.selection.createRange().text;
    }
    // console.log("dblclick presenter")
    if(selectedText.toString().length > 1)
        browser.runtime.sendMessage({"term": selectedText.toString()})
}
function handleResponse(message){
    console.log("Response received ");
}
function handleError(error){
    console.log("Error: "+error);
}

browser.runtime.onMessage.addListener(function(msg){
    console.log("selected text is "+selectedText.toString())
    definitions = msg.response
    // console.log(definitions)
    var oRange = selectedText.getRangeAt(0);
    var oRect = oRange.getBoundingClientRect();
    var dictBoxPadding = 10;
    var dictBoxMaxWidth = 350;
    var tooltipDictBox;
    var dictBoxLeftOffset;
    var pageWidth;

    tooltipDictBox = document.getElementById("tooltipDictBox");
    
    
    if(!tooltipDictBox) {

        tooltipDictBox = document.createElement('p');
        tooltipDictBox.id = "tooltipDictBox";
        document.body.appendChild(tooltipDictBox);

        tooltipDictBox.style.boxShadow = "5px 5px 5px #888888";
        tooltipDictBox.style.position = 'absolute'; 
        tooltipDictBox.style.zIndex = "1000"; 
        tooltipDictBox.style.top = oRect.top - tooltipDictBox.style.height+window.scrollY + 'px';
        tooltipDictBox.style.backgroundColor = "#ffffff";
        tooltipDictBox.style.padding = dictBoxPadding + "px";
        tooltipDictBox.style.fontFamily = "Arial";
        tooltipDictBox.style.fontSize = "13px";
        tooltipDictBox.style.borderRadius = "0px 5px 5px 5px";
        tooltipDictBox.style.maxWidth = dictBoxMaxWidth + "px";
    
        dictBoxLeftOffset = oRect.left + oRect.width + window.scrollX + 1;
        pageWidth = $(window).width();
        if ( (dictBoxMaxWidth + dictBoxLeftOffset ) > (pageWidth - dictBoxPadding)) {
            dictBoxLeftOffset = pageWidth - dictBoxMaxWidth - dictBoxPadding;
        }

        tooltipDictBox.style.left = dictBoxLeftOffset + 'px';
    }
    else
        $(tooltipDictBox).html("")

    if (!msg.response.length) {
        elem = document.createElement("p")
        $(elem).text("Definition not found!")
        tooltipDictBox.appendChild(elem)
        anchor_tag = document.createElement("a")
        $(anchor_tag).attr("href", "https://google.co.in/search?q="+selectedText)
        $(anchor_tag).attr("target", "_blank")
        $(anchor_tag).text("Search on google")
        tooltipDictBox.appendChild(anchor_tag)
        return;
    }

    var old_pos = ""; //pos = parts of speech
    definitions.forEach((defn, index)=> {
        if(old_pos != defn.partOfSpeech)
        {
            old_pos = defn.partOfSpeech
            elem = document.createElement("b")
            tooltipDictBox.appendChild(elem)
            $(elem).text(defn.partOfSpeech)
        }
        elem = document.createElement("div")
        tooltipDictBox.appendChild(elem)
        $(elem).text(index+1+": "+defn.text)
    })
    anchor_tag = document.createElement("a")
    $(anchor_tag).attr("href", "https://google.co.in/search?q=define "+selectedText)
    $(anchor_tag).attr("target", "_blank")
    $(anchor_tag).text("Search on google")
    tooltipDictBox.appendChild(anchor_tag)

    // var content =  DOMPurify.sanitize(msg.response, {
    //   SAFE_FOR_JQUERY: true,
    //   ADD_ATTR: ["target"]
    // });
    // $(tooltipDictBox).html(msg.response);
});

$(document).click(function(event){
    if(!document.getElementById("tooltipDictBox").contains(event.target)){
        $("#tooltipDictBox").remove();
    }else{
        if(document.getElementById("closeBtnEPD").contains(event.target)){
            $("#tooltipDictBox").remove();
        }
    }
});

